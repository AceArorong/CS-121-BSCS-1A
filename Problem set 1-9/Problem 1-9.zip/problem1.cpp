#include <iostream>

using namespace std;

int main(){

    cout << "*********************************\n";
    cout << "*\tProgramming Exercises\t*\n";
    cout << "*\tC++ Programming\t\t*\n";
    cout << "*\tAuthor: DS.Malik\t*\n";
    cout << "*\t\t\t\t*\n";
    cout << "*********************************" << endl;

    return 0;
}